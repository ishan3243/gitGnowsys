from south.db import db
from django.db import models

class Migration:
    
    def forwards(self):
        pass
    
    def backwards(self):
        pass

