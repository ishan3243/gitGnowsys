See collective/watcherlist/README.rst.
