#!/usr/bin/python2.4

print "Location: http://code.google.com/p/google-mobwrite/"
